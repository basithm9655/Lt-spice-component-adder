========================================================================
LTspice Component Adder Pro (v2.3.0)
Syllabus & Standard Semiconductor Library for LTspice XVII & LTspice 24
Built by Basi
========================================================================

HOW TO RUN:
1. Double-click "ltspice-component-adder.exe" to launch the tool.
2. Select your LTspice installation path (auto-detected).
3. Click "⚡ Add All (59)" to instantly install and verify all 59 components.
4. Launch LTspice — find all models under [AutoAdded] or in standard component pickers.

FEATURES:
- 59 Authentic SPICE Models (Germanium Diodes, BJTs, FETs, Regulators, UJTs, Digital)
- 1-Click Instant Add & Native Database Sync
- Smooth & Lightweight for Windows 10 & 11
- GitHub In-App Auto-Updater

Official Website: https://lt-spice-component-adder.vercel.app/
========================================================================
